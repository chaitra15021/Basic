using System;
using System.Collections.Generic;
using StockApp.Models;
using Microsoft.EntityFrameworkCore.DbContext;


namespace StockApp.DbContext
{
    public class AppDbContext : DbContext
    {
        
    public DbSet<StockData> Stocks { get; set; }

    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
    }
    }
}